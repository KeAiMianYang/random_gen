chaque fichier contient des algorithmes permettant de générer des maps 1D aléatoires.
